from flask import Flask, request, render_template, redirect


# Create a Flask app
def create_app():
    app = Flask(__name__)

# upload csv file that needs to be processed
    @app.route('./upload', methods=['GET', 'POST'])
    def index():
        if request.method == 'POST':
            return redirect(('download'))

        return render_template('upload.html')
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(port=5000, debug=True)
# IDG2001-Assignment1

- install dependencies/requirements using "pip install -r requirements.txt"

- In this assignment, we will create a simple web service where a user can upload files, the
system will process them, and return new/processed files
